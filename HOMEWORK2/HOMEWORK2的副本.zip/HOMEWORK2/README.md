
Instructions
=========================

Here is instructions to use kdTree python program 
  
##1.change dictionary 's path.
	In my program I put data file at:/Users/crispus/Desktop/machine learning/hw02/inputData/
		You can change program's  data file's dictionary  path in the program's global variable "filepath".
	 filepath = ""/Users/crispus/Desktop/machine learning/hw02/inputData/"'
	 
	

##2. the command lines

	1. input file. 
    
   + you can input like"2d_small.txt 4". If you do not input right form, the program will prompt you.    	



   
    2. Print tree leaves? Yes or no?, anything else for no:
   + If you want to show the tree, input "yes",anything else will not show the tree.     

    3. Test data? Yes or no, anything else for no:

  + If you want to test the function which show the data in which dataset, find the nearest point and show the distance, input "yes",anything else will not show the information
	



   
    4. name of data file:
   + you can input like"2dtest.txt" to test this file's data. If you input wrong format, the project will prompt you,and you need operate system back to first step.

    
	       

##2. the python version.  

	python 3.7
