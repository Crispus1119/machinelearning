
Instructions
=========================

Here is instructions to use  python program 
  
##1.change dictionary 's path.
	In my program I put data file at:"/Users/crispus/Downloads/hw05/pipe_world.txt"
		You should change:
		1.If you want run "fbVersion.py" you should change program's  data file's dictionary  path in the program's "loadEnvironment()" method to location in your computer.
	    2. If you want run "qlearning.py" you should change program's  data file's dictionary  path in the program's "loadReward()" method to location in your computer.	


    
	     
##2. the python version.  

	python 3.7,and you should have numpy model.
