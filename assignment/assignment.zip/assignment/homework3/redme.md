Instructions
=========================

Here is instructions to use neural network python program 
  
##1.change dictionary 's path.
	In my program I put training data file at:"/Users/crispus/Desktop/machine learning/hw03/trainSet_data/
	
	And Testing data at"/Users/crispus/Desktop/machine learning/hw03/testSet_data/":
		You can change program's  data file's dictionary  path in the program's global variable "datapathTraindata"and " datapathTestdata" to the path in your diagram.

	

##2. the command lines

	1. Enter l to load trained network, t to train a new one, q to quit 
    
   + you can choose the model you want to use.But if you don't save the network,the model of loading will be fail.



   
    2. Resolution of data (5/10/15/20)
   + Choose the data set to train and test.     

    3. Number of hidden layers:

  + if you want add  more hidden layer input how many you want.
	



   
    4. Size of hidden layer:
   + you can input number of nodes you want in each layer.
   
    5. Save network(y/n)?:
   + if you want save network press y.It will save in perceptron.nnet
   
    6. File name:
   + you can input the file you want to load or save.You can open the file saved before name is perceptron.nnet.

	       

##2. the python version.  

	python 3.7, and ensure you have numpy model.
##3.Apologize
    Sorry professor, I really do not know how to fix it,my best accuracy is 20.5%.I really try my best.
