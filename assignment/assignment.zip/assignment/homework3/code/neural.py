import random
import numpy as np
import re
import pickle
import sys
import os
import numpy.core.fromnumeric
datapathTraindata= "/Users/crispus/Desktop/machine learning/hw03/trainSet_data/"
datapathTestdata="/Users/crispus/Desktop/machine learning/hw03/testSet_data/"


# This is nerual class to record and make neural netWork for the data
class neural(object):
    def __init__(self, sizes):
        self.sizes_ = sizes
        self.num_layers_ = len(sizes)
        self.w_ = [np.random.rand(y, x) for x, y in zip(sizes[:-1], sizes[1:])]
        self.b_ = [np.random.rand(y, 1) for y in sizes[1:]]

    def erro_calculate(self, output, y):
        return y-output

    #this is method to test neural net work
    def testNet(self,testdata):
        le = int(len(testdata) / 2)
        calculate=0
        for i in range(le):
           teData=[x/255 for x in testdata[2*i]]

           x= self.feedforward(teData)
           x=x.flatten()
           if np.argmax(x, axis=0)==np.argmax(testdata[2*i+1]):
               calculate=calculate+1
        accurcy=str(calculate/le*100)
        print("accuracy achieved: "+accurcy+ " %")
        return calculate/le

    def feedforward(self, x):
        x=np.array(x).reshape(len(x),1)
        for bias,weight in zip(self.b_,self.w_):
            x = self.sigmoid(np.dot(weight, x) + bias)
        return x
    def makenetwork(self,traindata,testdata):
      le=int(len(traindata)/2)
      lable=0
      for j in range(1000):
          chan_b = [np.zeros(b.shape) for b in self.b_]
          chan_w = [np.zeros(w.shape) for w in self.w_]
          for i in range(int(le/2)):
              lable=lable+1
              a=random.randint(0,le-1)
              change_w, change_b = self.updata(traindata[2 * a], traindata[2 * a+ 1])
              changetransfer_b = transform_b(change_b, self.num_layers_)
              chan_b=[b + change for b, change in zip(chan_b, changetransfer_b)]
              chan_w = [w + change for w, change in zip(chan_w,change_w )]

          if self.testNet(testdata)>0.98:
              break
      accurcy = str(self.testNet(testdata) * 100)
      print("accuracy achieved: "+accurcy+ " %")
    # def makenetwork(self,traindata):
    #    le=int(len(traindata)/2)
    #    for i in range(le):
    #       change_w,change_b=self.updata(traindata[2*i],traindata[2*i+1])
    #       changetransfer_b=transform_b(change_b,self.num_layers_)
    #       self.w_= [w+change for w, change in zip(self.w_, change_w)]
    #       self.b_ = [b + change for b, change in zip(self.b_,changetransfer_b)]

    def updata(self, traindata,outputdata):
        #record all the change in this two
        change_b = [np.zeros(b.shape) for b in self.b_]
        change_w = [np.zeros(w.shape) for w in self.w_]
        record=[]
        traindata=[x/255 for x in traindata]
        activation = np.transpose([traindata])
        activations=[traindata]
        # calculate all the activition number
        for bias,weight in zip(self.b_,self.w_):
            input=np.dot(weight,activation)+bias
            record.append(input)
            activation=self.sigmoid(input)
            activations.append(activation)
        erro=self.erro_calculate(activations[-1],np.transpose([outputdata]))
        derivative=self.sigmoid_prime(record[-1])
        data1=np.array(erro.flatten())
        data2=np.array(derivative.flatten())
        delta=data1*data2
        change_b[-1]=delta
        change_w[-1]=np.dot(delta.reshape(len(delta),1), activations[-2].reshape(1,len(activations[-2])))
        for layer in range(2,self.num_layers_):
            rec=record[-layer]
            derivative2=self.sigmoid_prime(rec)#calculate the delta backword
            data=np.dot(self.w_[-layer+1].transpose(),delta.reshape(len(delta),1))
            delta=data*derivative2
            change_b[-layer] = delta.flatten()
            change_w[-layer]=np.dot(delta.reshape(len(delta),1), np.array(activations[-layer-1]).reshape(1,len(activations[-layer-1])))
        return change_w,change_b

    def sigmoid(self, z):
        return 1.0 / (1.0 + np.exp(-z))

    def sigmoid_prime(self, z):
         return self.sigmoid(z) * (1 - self.sigmoid(z))


def creatRandomWeight(a,b):
    weightlist = []
    for i in range(a):
        weight = []
        for j in range(b):
            weight.append(random.random())
        weightlist.append(weight)
    return weightlist


def buildNetwork():
    testdatapath=""
    data=input("Resolution of data (5/10/15/20)")
    datapath=""
    global datapathTraindata
    if data =="5" or data=="10" or data=="15" or data=="20":
        if data=="5":
            datapath = datapathTraindata+"trainSet_0"+data+".dat"
            testdatapath=datapathTestdata+"testSet_0"+data+".dat"
        else:
            datapath=datapathTraindata+"trainSet_"+data+".dat"
            testdatapath=datapathTestdata+"testSet_"+data+".dat"
    else:
        print("your input is not valid ,please try again")
        buildNetwork()
    traindata = dataloader(datapath)
    testdata = dataloader(testdatapath)
    num_hideenlayer=input("Number of hidden layers:")
    hideenlayer=[]
    if int(num_hideenlayer)>0:
        for i in range(int(num_hideenlayer)):
            size_of_layer=input("Size of hidden layer"+str(i+1)+" :")
            hideenlayer.append(int(size_of_layer))
    else:
        hideenlayer=[10]
    sizes=[len(traindata[0])]
    sizes=sizes+hideenlayer
    sizes.append(len(traindata[1]))
    net=neural(sizes)
    print("Initializing network...")
    print("Training on: "+datapath+"...")
    net.makenetwork(traindata,testdata)
    print("Testing on :"+testdatapath+"...."+"/n")
    net.testNet(testdata)
    save=input("Save network (y/n)? ")
    if save=="y":
        savepath = input("File-Name")
        file=open(savepath,"wb+")
        temp_dict={'sizes':net.sizes_,'weight':net.w_,'bias':net.b_,'testdatapath':testdatapath,'hiddenlayer':hideenlayer}
        pickle.dump(temp_dict,file)
        file.close()


def dataloader(filename):
        data = []
        str = ""
        try:
            with open(filename) as textdata:
                linedata = []
                for line in textdata:
                    if "#" in line:
                        continue
                    str = str + line.strip('\n')
                p1 = re.compile(r'[(](.*?)[)]', re.S)
                it = re.finditer(p1, str)
                for match in it:
                    data.append(match.group())

        except FileNotFoundError:
            print("Your file can not be found,please operate again")
        data = changeFloat(data)
        return data


def changeFloat(data):
    floatdata = []
    for i in data:
        dat = []
        for strs in i.strip('(').strip(')').split(" "):
            dat.append(float(strs))
        floatdata.append(dat)

    global size_of_input
    # size_of_input = len(floatdata[1])
    return floatdata


def transform_b(change_b,number):
    changetransfer_b = []
    for i in range(number - 1):
        change = []
        for j in range(len(change_b[i])):
            change.append([change_b[i][j]])
        changetransfer_b.append(np.array(change))
    return changetransfer_b


def loadnetwork():
    loadfile=input("Network file-name: ")
    file = open(loadfile, 'rb')
    temp_dict = pickle.load(file)
    file.close()
    print("Input layer size:  "+str(temp_dict['sizes'][0]))
    print("Hidden layer size:  "+ str(temp_dict['hiddenlayer']))
    print("Output layer size:  "+str(temp_dict['sizes'][-1]))
    print("Testing on :  "+temp_dict['testdatapath'])
    loadneur=neural(temp_dict['sizes'])
    loadneur.b_=temp_dict['bias']
    loadneur.w_=temp_dict['weight']
    testdata=dataloader(temp_dict['testdatapath'])
    loadneur.testNet(testdata)


if __name__ == '__main__':
    np.set_printoptions(suppress=True)
    while 1==1:
        model=input("Enter l to load trained network, t to train a new one, q to quit: ")
        if model=="t":
             buildNetwork()
        if model=="l":
             loadnetwork()
        if model=="q":
            break
    print("goodbye! have a good day!")