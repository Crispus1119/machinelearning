
Instructions
=========================

Here is instructions to use java program 
  
##1.input file of data set.
	In my program I put data set at:/Users/crispus/Documents/mushroom_data.txt
	You can change my program's  data set's path in the "main".
	 'String input = "/Users/crispus/Documents/mushroom_data.txt";'
	 You can change parameter "input" to the path of data set in your computer.
	

##2. the command lines

	1. please input a  a positive multiple of 250 that is <= 1000 to be the training set's size. 
    
   + you can input " 250","500","750","1000".      	


input the maximum of your training set.
   
    2. Please enter a training increment (either 10, 25, or 50):  
   + You can input "10","25","50".   

input your increment of your training set.

	3.Verbose mode? yes or no

  + You can input"yes" or "no".

Input the model you want to choose. If you input"yes",the console will show the detail of tree's branch.
    
	       

##2. the JDK version.  

	JDK 1.8.0

